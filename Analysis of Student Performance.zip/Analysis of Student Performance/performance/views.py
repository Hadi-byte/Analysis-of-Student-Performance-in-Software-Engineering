from django.shortcuts import render, redirect
from .forms import PerformanceDataForm, StudentForm, CourseForm
from django.shortcuts import render
from .models import PerformanceData

# View to display performance analysis
def performance_analysis(request):
    performances = PerformanceData.objects.all()  # Fetch all performance data
    return render(request, 'performance/performance_analysis.html', {'performances': performances})

# View to handle the submission of performance data
def collect_performance_data(request):
    if request.method == 'POST':
        form = PerformanceDataForm(request.POST)
        if form.is_valid():
            form.save()  # Save the data to the database
            return redirect('performance_analysis')  # Redirect to analysis page
    else:
        form = PerformanceDataForm()
    return render(request, 'performance/collect_performance_data.html', {'form': form})

# View to register a new student
def register_student(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()  # Save the student data to the database
            return redirect('student_list')  # Redirect to the student list page
    else:
        form = StudentForm()
    return render(request, 'performance/register_student.html', {'form': form})

# View to create a new course
def create_course(request):
    if request.method == 'POST':
        form = CourseForm(request.POST)
        if form.is_valid():
            form.save()  # Save the course data to the database
            return redirect('course_list')  # Redirect to the course list page
    else:
        form = CourseForm()
    return render(request, 'performance/create_course.html', {'form': form})
