from django.urls import path
from . import views

urlpatterns = [
    path('', views.collect_performance_data, name='collect_performance_data'),
    path('register_student/', views.register_student, name='register_student'),
    path('create_course/', views.create_course, name='create_course'),
    path('performance_analysis/', views.performance_analysis, name='performance_analysis'),
]
