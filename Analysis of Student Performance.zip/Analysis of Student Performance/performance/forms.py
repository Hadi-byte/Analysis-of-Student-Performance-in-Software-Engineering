from django import forms
from .models import Student, Course, PerformanceData

# Form to collect performance data for students
class PerformanceDataForm(forms.ModelForm):
    class Meta:
        model = PerformanceData
        fields = ['registration_number', 'exam_name', 'student_name', 'score']

# Form to register students
class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['first_name', 'last_name', 'email']

# Form to create new courses
class CourseForm(forms.ModelForm):
    class Meta:
        model = Course
        fields = ['name', 'description']
